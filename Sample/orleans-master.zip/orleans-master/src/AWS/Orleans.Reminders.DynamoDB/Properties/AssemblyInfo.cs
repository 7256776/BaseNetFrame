﻿using System.Runtime.CompilerServices;
using Orleans.CodeGeneration;

[assembly: InternalsVisibleTo("AWSUtils.Tests")]

[assembly: SkipCodeGeneration]