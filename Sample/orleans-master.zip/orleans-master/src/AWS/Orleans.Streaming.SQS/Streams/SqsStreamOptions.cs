﻿
namespace Orleans.Configuration
{
    public class SqsOptions
    {
        [Redact]
        public string ConnectionString { get; set; }
    }
}
