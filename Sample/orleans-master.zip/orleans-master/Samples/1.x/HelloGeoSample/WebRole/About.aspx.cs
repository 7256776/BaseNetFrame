﻿using System;
using System.Web.UI;

namespace Orleans.Azure.Samples.Web
{
    public partial class About : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}