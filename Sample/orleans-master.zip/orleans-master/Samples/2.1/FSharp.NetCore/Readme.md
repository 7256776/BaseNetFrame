### run silo host
```sh
cd .\src\FSharp.NetCore.SiloHost
dotnet restore
dotnet run
```

### run client
```sh
cd .\src\FSharp.NetCore.Client
dotnet restore
dotnet run
```
