# Stocks example code

Orleans Stocks sample targeting .NET Core

Docs describing this code are published at https://dotnet.github.io/orleans/1.5/Tutorials/Interaction-with-Libraries-and-Services.html

