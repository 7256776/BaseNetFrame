./build.ps1 -target Release
exit $LASTEXITCODE