#!/usr/bin/env bash

./build.sh --target RunUnitTests