namespace Ocelot.Responses
{
    public class OkResponse : Response
    {
        public OkResponse()
        {
        }
    }
}