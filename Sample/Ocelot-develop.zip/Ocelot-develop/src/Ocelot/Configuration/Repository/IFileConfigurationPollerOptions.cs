﻿namespace Ocelot.Configuration.Repository
{
    public interface IFileConfigurationPollerOptions
    {
        int Delay { get; }
    }
}
