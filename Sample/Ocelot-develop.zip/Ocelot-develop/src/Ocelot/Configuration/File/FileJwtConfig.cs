﻿namespace Ocelot.Configuration.File
{
    public class FileJwtConfig
    {
        public string Authority { get; set; }

        public string Audience { get; set; }
    }
}