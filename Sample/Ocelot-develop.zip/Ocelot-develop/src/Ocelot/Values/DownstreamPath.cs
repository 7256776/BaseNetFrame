﻿namespace Ocelot.Values
{
    public class DownstreamPath
    {
        public DownstreamPath(string value)
        {
            Value = value;
        }

        public string Value { get; }
    }
}
