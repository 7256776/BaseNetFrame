using System;
using Ocelot.Values;

namespace Ocelot.LoadBalancer.LoadBalancers
{
    public class StickySession
    {
        public StickySession(ServiceHostAndPort hostAndPort, DateTime expiry, string key)
        {
            HostAndPort = hostAndPort;
            Expiry = expiry;
            Key = key;
        }

        public ServiceHostAndPort HostAndPort { get; }
        
        public DateTime Expiry { get; }

        public string Key {get;}
    }
}
