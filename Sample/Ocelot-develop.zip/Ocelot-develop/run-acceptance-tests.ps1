./build -target RunAcceptanceTests
exit $LASTEXITCODE