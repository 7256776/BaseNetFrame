./build.ps1 -target RunUnitTests
exit $LASTEXITCODE