./build.ps1 -target RunTests
exit $LASTEXITCODE