./build.ps1 -target RunBenchmarkTests
exit $LASTEXITCODE