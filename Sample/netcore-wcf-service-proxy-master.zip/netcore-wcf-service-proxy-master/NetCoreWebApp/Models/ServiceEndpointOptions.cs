﻿namespace NetCoreWebApp.Models
{
    public class ServiceEndpointOptions
    {
        public string CountryService { get; set; }
        public string PersonService { get; set; }
    }
}
